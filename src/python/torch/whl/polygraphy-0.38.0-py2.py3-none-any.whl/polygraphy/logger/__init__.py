from polygraphy.logger.logger import G_LOGGER, LogMode
